import fs from 'node:fs';
import path from 'node:path';

const relative = 'public/modules/phase3/phase3-homologation.css';
const file = path.join(process.cwd(), relative);
if (!fs.existsSync(file)) {
  console.error(`Arquivo não encontrado: ${relative}. Execute na raiz do ERP.`);
  process.exitCode = 1;
} else {
  const original = fs.readFileSync(file, 'utf8');
  if (!original.includes('#phase3-cheque-gaps')) {
    console.error('Seletor do painel de cheques não encontrado. Não alterei o CSS.');
    process.exitCode = 1;
  } else if (original.includes('#phase3-cheque-gaps{max-height:108px;overflow-y:auto}')) {
    console.log('A regra de limite de altura já existe. Nenhuma alteração necessária.');
  } else {
    const fix = [
      '',
      '/* Proteção contra listas extensas de lacunas de cheques */',
      '#phase3-cheque-gaps{max-height:108px;overflow-y:auto}',
      '#phase3-cheque-gaps>div{max-width:100%;overflow-wrap:anywhere;line-height:1.35}',
      ''
    ].join('\n');
    fs.writeFileSync(file, original.trimEnd() + '\n' + fix, 'utf8');
    console.log(`Ajuste aplicado somente em ${relative}`);
  }
}
