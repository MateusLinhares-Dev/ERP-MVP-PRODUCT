import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

const purchase=readFileSync(new URL('../public/modules/purchase-order/purchase-order.js',import.meta.url),'utf8');
const core=readFileSync(new URL('../public/legacy/app-core.js',import.meta.url),'utf8');
function extract(source,start,end){
  const first=source.indexOf(start);
  const last=source.indexOf(end,first);
  assert.ok(first>=0&&last>first,`function range missing: ${start}`);
  return source.slice(first,last);
}

test('cheque oferece clientes e fornecedores ativos com destino identificável',()=>{
  const code=extract(core,'function _chqCadastroDestinos(){','function _chqModal(id){');
  const ctx={CLIENTES:[{nome:'CLIENTE TESTE',cod:'C1'}],FORNECEDORES:[{nome:'JOAO ELIAS',cod:'F3'},{nome:'FORN INATIVO',inativo:true}]};
  const found=runInNewContext(`${code}\n_chqCadastroDestinos()`,ctx);
  assert.ok(found.some(x=>x.nome==='JOAO ELIAS'&&x.tipo==='Fornecedor'&&x.cod==='F3'));
  assert.ok(found.some(x=>x.nome==='CLIENTE TESTE'&&x.tipo==='Cliente'));
  assert.ok(!found.some(x=>x.nome==='FORN INATIVO'));
  assert.match(core,/obj\.fornecedorCod=_selected\.cod/);
  assert.doesNotMatch(core,/id=\"chqm-clientes-list\"/);
  assert.match(core,/id=\"chqm-destino-opcoes\"/);
});

test('cheque usa fornecedores ativos da mesma fonte da aba Fornecedores, mesmo com lista inicial vazia',()=>{
  const code=extract(core,'function _chqCadastroDestinos(){','function _chqBindDestinoAutocomplete(ov){');
  const ctx={CLIENTES:[{cod:'C1',nome:'CLIENTE TESTE'}],FORNECEDORES:[],FORNECEDORES_DESPESA:[],
    getFornAtivos(){return [{cod:'F003',nome:'JOAO ELIAS'},
      {cod:'F002',nome:'TESTANDO MINHA PACIENCIA KKK'},
      {cod:'F004',nome:'INATIVO',inativo:true}];}};
  const result=runInNewContext(code+'\n_chqCadastroDestinos()',ctx);
  assert.deepEqual(Array.from(result.filter(x=>x.tipo==='Fornecedor'),x=>x.nome),
    ['JOAO ELIAS','TESTANDO MINHA PACIENCIA KKK']);
  assert.equal(result[0].cod,'F003');
});

test('cheque salva o código do fornecedor escolhido, não o código de cliente com nome parecido',async()=>{
  const code=extract(core,'function _chqCadastroDestinos(){','function _chqBindDestinoAutocomplete(ov){')+'\n'+
    extract(core,'function chqSalvarModal(){','var _CHQ_FIX_GS=[];');
  const form={
    'chqm-id':'','chqm-b':'as','chqm-n':'200','chqm-c':'JOAO ELIAS',
    'chqm-v':'1500,00','chqm-s':'A','chqm-d':'27/10/2026',
    'chqm-venc':'28/10/2026','chqm-cd':'',
    'chqm-destino-cod':'F003','chqm-destino-tipo':'Fornecedor'
  };
  let saved;
  const ctx={
    CLIENTES:[{cod:'C1',nome:'JOAO ELIAS'}],
    FORNECEDORES:[{cod:'F003',nome:'JOAO ELIAS'}],FORNECEDORES_DESPESA:[],
    getFornAtivos(){return ctx.FORNECEDORES;},
    document:{getElementById(id){return form[id]===undefined?null:{value:form[id]};}},
    _chqParseVal(s){return Number(String(s).replace(',','.'));},
    _chqRef(){return {child(){return {set(obj){saved=obj;return Promise.resolve();}}}};},
    _cfgChequeBankSlug(){return 'AS';},
    CHQ_CTRL:{},renderChequesCompensar(){},chqFecharModal(){},showToast(){}
  };
  runInNewContext(code+'\nchqSalvarModal()',ctx);
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(saved.fornecedorCod,'F003');
  assert.equal(saved.fornecedorNome,'JOAO ELIAS');
  assert.equal(saved.clienteCod,undefined);
});

test('adiantamentos recém-cadastrados prevalecem sobre dataset financeiro vazio',()=>{
  const code=extract(purchase,'function financialData(body,supplierCode,sourceTicketKeys=[]){','function currentState(body){');
  const ctx={
    jsonDataset:(b,k,f)=>JSON.parse(b.dataset[k]||'null')??f,
    ADT_POR_FORN:{F3:[{cod:'A1',valor:100000,status:'Pendente',forma:'PIX'},{cod:'A2',valor:50000,status:'Pendente',forma:'PIX'},{cod:'A3',valor:35000,status:'Pendente',forma:'PIX'}]},
    CHEQUES_POR_FORN:{},SALDO_DEVEDOR_FORN:{},tickets(){return {};},linkedPurchase(){return null;}
  };
  const body={dataset:{fornCod:'F3',adtsData:'[]',cheqsData:'[]',saldoAnterior:'0'}};
  ctx.body=body;
  const result=runInNewContext(`${code}\nfinancialData(body,'F3')`,ctx);
  assert.equal(result.adts.length,3);
  assert.equal(result.adts.reduce((sum,a)=>sum+a.valor,0),185000);
});

test('editar pedido altera materiais sem reaplicar adiantamentos e atualiza apenas saldo restante',()=>{
  const code=extract(purchase,'function saveEditedTicket(state,totals){','function stateForSourceTicket(ticketKey){');
  const ticket={ticket:'T100',fornecedor:'JOAO ELIAS',fornecedorCod:'F3',totalGeral:1000,
    totalProdutos:1000,adiantamento:300,saldoPagar:700,status:'Pendente',
    reciboFinanceiro:{adiantamentos:[{cod:'ADT100',valorAplicado:300}]},
    itens:[{mat:'ALUMINIO',quantidade:100,pesoLiq:100,pesoBruto:100,preco:10,ident:'LIMPO'}]};
  const adts=[{cod:'ADT100',valor:300,status:'Quitado',ticket:'T100'}];
  const cp={ticket:'T100',valor:700,status:'Pendente',id:'CP1'};
  let saved=0, savedCp=0;
  const ctx={
    TICKETS_DB:{k1:ticket},ADT_POR_FORN:{F3:adts},CHEQUES_POR_FORN:{},
    CONTAS_PAGAR:[cp],global:{},
    tickets(){return this.TICKETS_DB;},
    supplierByName(){return {cod:'F3',nome:'JOAO ELIAS'};},
    saveDB(){saved++;},saveContasPagar(){savedCp++;},
    fbSalvarImediato(){},registrarHistorico(){},itemNet(x){return Number(x.quantidade??x.pesoLiq??0);}
  };
  // Pass a closure that works as it does in the browser, without `this` dependencies.
  ctx.tickets=()=>ctx.TICKETS_DB;
  const state={editKey:'k1',ticketSnapshot:JSON.stringify(ticket),supplierName:'JOAO ELIAS',supplierCode:'F3',originalTotal:1000,originalBalance:700,
    items:[{mat:'ALUMINIO',originalIndex:0,ident:'LIMPO',quantidade:100,pesoBruto:100,preco:10},
           {mat:'COBRE',quantidade:10,pesoBruto:10,preco:20}],
    discount:0,freight:0,orderNumber:'T100',purchaseOrder:'',purchaseDate:'2026-10-27',dueDate:'2026-10-30',notes:'Teste'};
  ctx.state=state;
  const edited=runInNewContext(`${code}\nsaveEditedTicket(state, {total:1200,productTotal:1200,balance:900})`,ctx);
  assert.equal(ticket.itens.length,1);
  assert.equal(ticket.saldoPagar,700);
  assert.equal(cp.valor,700);
  assert.equal(saved,0);assert.equal(savedCp,0);
  assert.equal(edited.itens.length,2);
  assert.equal(edited.itens[0].ident,'LIMPO');
  assert.equal(edited.itens[1].mat,'COBRE');
  assert.equal(edited.saldoPagar,900);
  ctx.edited=edited;
  runInNewContext(`${code}\nafterConfirmedPurchaseEdit(edited,state,{total:1200,productTotal:1200,balance:900})`,ctx);
  assert.equal(cp.valor,700);
  assert.equal(ticket.adiantamento,300);
  assert.equal(ticket.reciboFinanceiro.adiantamentos[0].valorAplicado,300);
  assert.equal(adts[0].status,'Quitado');
  assert.equal(saved,0);assert.equal(savedCp,0);
});

test('edição impede preço total inferior ao já pago/abatido',()=>{
  const code=extract(purchase,'function saveEditedTicket(state,totals){','function stateForSourceTicket(ticketKey){');
  const ticket={ticket:'T1',totalGeral:1000,saldoPagar:0,itens:[{mat:'COBRE',quantidade:1,preco:1000}]};
  const ctx={TICKETS_DB:{T1:ticket},ticket,tickets:()=>ctx.TICKETS_DB};
  assert.throws(()=>runInNewContext(`${code}\nsaveEditedTicket({editKey:'T1',ticketSnapshot:JSON.stringify(ticket),originalTotal:1000,originalBalance:0}, {balance:-1,total:999})`,ctx),/abaixo de pagamento já registrado/);
});

test('histórico navega para edição completa, atalho Alt+Z e impressão enxuta',()=>{
  assert.match(core,/onclick="phase4PurchaseEditTicket\('\$\{tk\._dbKey\}'\)"/);
  assert.match(purchase,/global\.phase4PurchaseEditTicket=async function/);
  assert.match(purchase,/global\.csTab\('lancamento'\)/);
  assert.match(purchase,/String\(ev\.key\|\|'?'\)\.toLowerCase\(\)!=='z'/);
  assert.match(purchase,/aria-keyshortcuts="Alt\+Z"/);
  assert.doesNotMatch(purchase,/<th>Código do fornecedor<\/th>/);
  assert.doesNotMatch(purchase,/<th>Código<\/th>/);
});

test('edição mantém valores extras legados sem modificar o total da compra ao abrir',()=>{
  const code=extract(purchase,'function stateForExistingTicket(key,cloudTicket){','global.phase4PurchaseEditTicket=async function');
  const ticket={ticket:'T200',fornecedor:'JOAO ELIAS',totalGeral:1165,saldoPagar:665,adiantamento:500,
    descontoCompra:0,freteCompra:0,acrescimo:165,
    itens:[{mat:'COBRE',pesoLiq:10,quantidade:10,preco:100}]};
  const ctx={
    tickets(){return {T200:ticket};},
    supplierByName(){return {nome:'JOAO ELIAS',cod:'F3'};},
    ticketItemsForOrder(){return [{mat:'COBRE',quantidade:10,preco:100,source:true}]},
    itemNet(i){return Number(i.quantidade||i.pesoLiq||0);},
    isoDate(){return '2026-10-27';},
    today(){return '2026-10-27';}
  };
  const state=runInNewContext(`${code}\nstateForExistingTicket('T200')`,ctx);
  assert.equal(state.legacyExtra,165);
  assert.equal(state.originalTotal,1165);
  assert.equal(state.originalBalance,665);
  assert.equal(state.appliedAdvance,500);
  assert.equal(state.items[0].source,false);
});
